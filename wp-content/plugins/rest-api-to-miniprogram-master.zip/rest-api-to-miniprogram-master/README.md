﻿# WordpPress rest api 定制化插件

# 为微信小程序、app提供定制 WordPress rest api

# 技术支持网站：https://www.watch-life.net

# 技术支持微信：iamxjb

# 讨论微信群：

由于微信群超过100人，无法再扫描二维码加入。如果你想加入，请先加我的微信：iamxjb ，我拉你入群。

# 开源协议：GPL v3

# 插件使用及注意事项见：

https://www.watch-life.net/wordpress-weixin-app

# 插件在Wordpress 官方更新地址：

https://wordpress.org/plugins/rest-api-to-miniprogram

# 插件镜像更新地址：

https://gitee.com/iamxjb/rest-api-to-miniprogram
https://github.com/iamxjb/rest-api-to-miniprogram
https://codechina.csdn.net/xjbx/rest-api-to-miniprogram




# 使用说明：

插件安装启用后，通过wordpress后台菜单“微信小程序设置”，进入设置页面，配置运行wordpress小程序需要的配置项。

![rest-api-to-miniprogram](https://raw.githubusercontent.com/iamxjb/rest-api-to-miniprogram/master/includes/images/rest-api-to-miniprogram.png) 
