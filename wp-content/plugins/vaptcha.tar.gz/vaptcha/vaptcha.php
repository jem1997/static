<?php
/*
Plugin Name: VAPTCHA 手势验证码
Plugin URI: https://www.vaptcha.com
Description: VAPTCHA是”Variation Analysis - based Public Turing Test to Tell Computers and Humans Apart ”的简称，也叫手势验证。一种通过用户鼠标手势即可完成人机验证的图灵测试程序。VAPTCHA更加简单和安全，是目前传统验证码的最佳替代方案。VAPTCHA不仅大幅节省了用户在使用互联网服务时在人机验证上面的耗时，平均通过时间不超过1秒，同时也是目前世界上最不可能被破解的验证系统。
Version: 3.0.3
Author: vaptcha
Text Domain: vaptcha
Domain Path: /languages
Author URI: https://github.com/vaptcha
*/

/*  Copyright 2017  vaptcha  (email : vaptcha@wlinno.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
if ( !defined('ABSPATH') ) {
   exit('No direct script access allowed');
}

require_once plugin_dir_path( __FILE__ ) . 'VaptchaPlugin.php';

if(class_exists("VaptchaPlugin")){
	$vaptcha = new VaptchaPlugin();
    $vaptcha->init();
}
?>