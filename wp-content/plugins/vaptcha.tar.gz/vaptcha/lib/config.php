<?php 
return array(
    'VALIDATE_PASS_TIME' => 600000,
    'REQUEST_ABATE_TIME' => 250000,
    'VALIDATE_WAIT_TIME' => 2000,
    'MAX_LENGTH' => 50000,
    'PIC_POST_FIX' => ".png",
    'Channel_DownTime' => "http://channel2.vaptcha.com/config/",
    'DOWN_TIME_PATH' => "offline/",
    'DOWNTIME_URL' => "https://offline.vaptcha.com/",
    'VERSION' => '3.0.3',
    'SDK_LANG' => 'php',
    'API_URL' => 'http://0.vaptcha.com',
    'GET_knock_URL' => '/knock',
    'VALIDATE_URL' => '/verify',
    'REQUEST_UESD_UP' => '0209',
    'DOWNTIME_CHECK_TIME' => 185000
);



